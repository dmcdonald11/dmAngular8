﻿Imports System
Imports System.Linq
Imports System.Net
Imports System.Net.Http
Imports System.Web.Http
Imports DotNetNuke.Web.Api
Imports DotNetNuke.Security
Imports NWSC.Modules.DMAngular8.Components
Imports System.Collections.Generic
Imports System.Data.SqlClient
Imports System.Web.Mvc
Imports DotNetNuke.Web.Mvc.Framework.Controllers


Namespace Services.Controllers

    <SupportedModules(Constants.DESKTOPMODULE_NAME)>
    Public Class homeController
        Inherits DnnController

        Public Function GetCalls() As JsonResult
            ' using entity framework
            'Dim db As New CallTrackerDBEntities
            'Dim Calls = db.CallTrackerCalls.ToList()
            'Return Json(Calls, JsonRequestBehavior.AllowGet)

            Dim dt As New DataTable()
            Dim mySQL As String
            'Use Connection string in DNN
            'Dim dbConn As  String = ConfigurationManager.ConnectionStrings("SiteSqlServer").ConnectionString

            mySQL = "Select CallId, CallDate, CallerName, CallerAddress, CallerCity," _
                    & "Region, UtilityType, CallBackNumber, CrossStreet, Comments," _
                    & "DispatchId, CallType, PortalId, ModuleId, LastModifiedOnDate," _
                    & "LastModifiedByUserId from dbo.CallTrackerCalls "

            'Using con As New SqlConnection(dbConn)
            Using con As New SqlConnection("Data Source=.;Initial Catalog=dnndev.me;Integrated Security=true")
                Using cmd As New SqlCommand(mySQL, con)
                    con.Open()
                    Dim da As New SqlDataAdapter(cmd)
                    da.Fill(dt)
                End Using
            End Using
            Return Json(ConvertDataTabletoString(dt), JsonRequestBehavior.AllowGet)

        End Function

        Public Function GetRegions() As JsonResult
            ' using entity framework
            'Dim db As New CallTrackerDBEntities
            'Dim Calls = db.CallTrackerCalls.ToList()
            'Return Json(Calls, JsonRequestBehavior.AllowGet)

            Dim dt As New DataTable()
            Dim mySQL As String
            'Use Connection string in DNN
            'Dim dbConn As  String = ConfigurationManager.ConnectionStrings("SiteSqlServer").ConnectionString

            mySQL = "Select RegionId, RegionDesc " _
                    & " from dbo.CallTrackerRegionDim "

            'Using con As New SqlConnection(dbConn)
            Using con As New SqlConnection("Data Source=.;Initial Catalog=dnndev.me;Integrated Security=true")
                Using cmd As New SqlCommand(mySQL, con)
                    con.Open()
                    Dim da As New SqlDataAdapter(cmd)
                    da.Fill(dt)
                    Return Json(ConvertDataTabletoString(dt), JsonRequestBehavior.AllowGet)
                End Using
            End Using

        End Function

        '  This function converts a Data Table to a string object that can be converted to JSON for the client side data binding.
        Private Function ConvertDataTabletoString(myDataTable As DataTable) As List(Of Dictionary(Of String, Object))

            Dim rows As New List(Of Dictionary(Of String, Object))()
            Dim row As Dictionary(Of String, Object)
            For Each dr As DataRow In myDataTable.Rows
                row = New Dictionary(Of String, Object)()
                For Each col As DataColumn In myDataTable.Columns
                    row.Add(col.ColumnName, dr(col))
                Next
                rows.Add(row)
            Next
            Return rows
        End Function


    End Class

End Namespace
