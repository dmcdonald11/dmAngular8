﻿
Namespace Components
    Public Class Constants
#Region "Misc."

        Public Const DESKTOPMODULE_NAME As String = "DMAngular6"
        Public Const DESKTOPMODULE_FRIENDLYNAME As String = "Angular Module Test"

#End Region

    End Class
End Namespace


