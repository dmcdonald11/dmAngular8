﻿var nwsc = nwsc || {};


//var myApp = angular.module('myApp', []);

//var myCTLApp = angular.module('myCTLApp', []);

nwsc.myCTLApp = angular.module('nwsc.myCTLApp', []);

nwsc.myCTLApp.controller('mainController', function ($http) {

    var vm = this;
    vm.show = 'default';

    //Get Calls
    $http.get('/home/GetCalls')
       .success(function (results) {
           vm.calls = results;
       })
       .error(function (data) {
           console.log(data);
       })

    vm.newCalls = '';
    vm.regions = '';
    vm.addCalls = function () {
        vm.show = 'new';
        $http.get('/home/GetRegions')
           .success(function (results) {
               vm.regions = results;
           })
           .error(function (data) {
               console.log(data);
           })

    }

    vm.Cancel = function () {
        vm.show = 'default';
    }

});
